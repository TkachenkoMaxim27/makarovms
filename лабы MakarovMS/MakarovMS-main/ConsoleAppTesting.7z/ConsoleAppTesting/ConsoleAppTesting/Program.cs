﻿using System.Runtime.CompilerServices;
///Задание:
///Консольное приложение.
///Программа запрашивает у пользователя ввод двух чисел
///Отслеживание некорректного ввода
///По двум числам нужно составить матрицу умножения
///x = 3, y = 4
///[1, 2, 3, 1x1 1x2 1x3
/// 2, 4, 6, 2x1 2x2 2x3
/// 3, 6, 9, ...
/// 4, 8, 12]
[assembly:InternalsVisibleTo("ConsoleInputOutputHandler")]
namespace ConsoleAppTesting
{
    public class Program
    {
       public static void Main(string[] args)
        {
            int x, y = 0;
            bool validInput = false;

            do
            {
                Console.WriteLine("Введите число x:");
                string inputX = Console.ReadLine();
                Console.WriteLine("Введите число y:");
                string inputY = Console.ReadLine();

                if (int.TryParse(inputX, out x) && int.TryParse(inputY, out y))
                {
                    validInput = true;
                }
                else
                {
                    Console.WriteLine("Некорректный ввод. Пожалуйста, введите целое число.");
                }
            } while (!validInput);

            int[,] multTable = new int[x, y];

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    multTable[i, j] = (i + 1) * (j + 1);
                }
            }

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    Console.Write(multTable[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}
    